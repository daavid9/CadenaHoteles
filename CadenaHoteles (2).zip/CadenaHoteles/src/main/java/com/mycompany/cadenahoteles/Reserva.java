/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

import java.util.Date;

/**
 *
 * @author david.b
 */


/**
 * Representa una reserva realizada por un cliente en un hotel.
 */
public class Reserva {
    private int idReserva;
    private int idCliente;
    private int idHabitacion;
    private Date fechaInicio;
    private Date fechaFin;
   /**
     * Constructor para inicializar un objeto Reserva.
     *
     * @param idReserva    El ID de la reserva.
     * @param idCliente    El ID del cliente que realiza la reserva.
     * @param idHabitacion El ID de la habitación reservada.
     * @param fechaInicio  La fecha de inicio de la reserva.
     * @param fechaFin     La fecha de fin de la reserva.
     */
    public Reserva(int idReserva, int idCliente, int idHabitacion, Date fechaInicio, Date fechaFin) {
        this.idReserva = idReserva;
        this.idCliente = idCliente;
        this.idHabitacion = idHabitacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Getters y setters
}

