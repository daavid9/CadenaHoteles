/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase representa la interfaz gráfica principal para la gestión de hoteles.
 * Permite a los empleados visualizar y gestionar habitaciones de diferentes hoteles.
 */
public class CadenaHoteles extends JFrame {
    private JComboBox<Hotel> hotelesComboBox;
    private JList<Habitacion> habitacionesList;
    private DefaultListModel<Habitacion> habitacionesListModel;
    private int idEmpleado; // Almacenar el ID del empleado
/**
     * Constructor de la clase CadenaHoteles.
     * @param  el ID del empleado que inicia sesión.
     */
    public CadenaHoteles(int idEmpleado) {
        super("Sistema de Gestión de Hoteles");
        this.idEmpleado = idEmpleado; // Inicializar el ID del empleado

        // Configurar el frame
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel de selección de hoteles
        JPanel hotelesPanel = new JPanel();
        JLabel hotelesLabel = new JLabel("Seleccione un hotel:");
        hotelesComboBox = new JComboBox<>();
        hotelesComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Lógica para cargar las habitaciones del hotel seleccionado
                Hotel hotelSeleccionado = (Hotel) hotelesComboBox.getSelectedItem();
                cargarHabitaciones(hotelSeleccionado);
            }
        });
        hotelesPanel.add(hotelesLabel);
        hotelesPanel.add(hotelesComboBox);
        add(hotelesPanel, BorderLayout.NORTH);

        // Lista de habitaciones
        habitacionesListModel = new DefaultListModel<>();
        habitacionesList = new JList<>(habitacionesListModel);
        habitacionesList.setCellRenderer(new HabitacionListRenderer());
        JScrollPane habitacionesScrollPane = new JScrollPane(habitacionesList);
        add(habitacionesScrollPane, BorderLayout.CENTER);

        // Conectar a la base de datos y cargar los hoteles al iniciar la aplicación
        conectarBaseDeDatos();

        // Botón de incidencias
        JButton incidenciasButton = new JButton("Incidencias");
        incidenciasButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Instanciar la clase Incidencias y mostrar el panel de incidencias
                Incidencias incidencias = new Incidencias();
                incidencias.mostrarPanelIncidencias();
            }
        });
        JPanel buttonPanel = new JPanel(); // Nuevo panel para contener el botón
        buttonPanel.add(incidenciasButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Botón de Stock
        JButton stockButton = new JButton("Stock");
        stockButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Instanciar la clase Stock y mostrar el panel de stock
                Stock stock = new Stock();
                stock.mostrarPanelStock();
            }
        });
        buttonPanel.add(stockButton); // Agregar el botón de stock al mismo panel
        
        // Acción para el botón "Horarios"
        JButton horariosButton = new JButton("Horario");
        horariosButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Instanciar la clase Horarios y mostrar el panel de horarios
                Horarios horarios = new Horarios();
                horarios.cargarHorarioEmpleado(idEmpleado);
                horarios.mostrarPanelHorarios();
            }
        });
        buttonPanel.add(horariosButton); // Agregar el botón de horarios al mismo panel
        
         // Botón de Devoluciones
        JButton devolucionesButton = new JButton("Devoluciones");
        devolucionesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Instanciar la clase Devolucion y mostrar el panel de devoluciones
                Devolucion devolucion = new Devolucion();
                devolucion.mostrarPanelDevolucion();
            }
        });
        buttonPanel.add(devolucionesButton); // Agregar el botón de devoluciones al mismo panel
    }
    /**
     * Método privado para establecer la conexión a la base de datos y cargar los hoteles.
     */

    private void conectarBaseDeDatos() {
        // Lógica para conectar a la base de datos
        try {
            Connection conn = BaseDeDatos.getConnection();

            // Cargar los hoteles desde la base de datos y agregarlos al ComboBox
            List<Hotel> hoteles = cargarHoteles(conn);
            for (Hotel hotel : hoteles) {
                hotelesComboBox.addItem(hotel);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private List<Hotel> cargarHoteles(Connection conn) throws SQLException {
        // Lógica para cargar la lista de hoteles desde la base de datos
        List<Hotel> hoteles = new ArrayList<>();
        String sql = "SELECT idHotel, nombre, direccion FROM hoteles";

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int idHotel = rs.getInt("idHotel");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                Hotel hotel = new Hotel(idHotel, nombre, direccion);
                hoteles.add(hotel);
            }
        }

        return hoteles;
    }
/**
     * Método privado para cargar las habitaciones de un hotel específico.
     * @param  el hotel del cual se cargarán las habitaciones.
     */
    private void cargarHabitaciones(Hotel hotel) {
        // Lógica para cargar las habitaciones del hotel seleccionado desde la base de datos
        int idHotel = hotel.getIdHotel();

        // Lógica para conectarte a la base de datos y obtener las habitaciones del hotel por su ID
        String sql = "SELECT idHabitacion, numero, tipo, estado FROM habitaciones WHERE idHotel = ?";
        List<Habitacion> habitaciones = new ArrayList<>();

        try (Connection conn = BaseDeDatos.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idHotel);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int idHabitacion = rs.getInt("idHabitacion");
                    int numero = rs.getInt("numero");
                    String tipo = rs.getString("tipo");
                    String estado = rs.getString("estado");
                    // Crear objeto Habitacion con los datos obtenidos de la base de datos
                    Habitacion habitacion = new Habitacion(idHabitacion, numero, tipo, estado, idHotel);
                    habitaciones.add(habitacion);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Actualizar el modelo de la lista con las habitaciones obtenidas
        habitacionesListModel.clear();
        for (Habitacion habitacion : habitaciones) {
            habitacionesListModel.addElement(habitacion);
        }
    }
/**
     * Método main para iniciar la aplicación.
     * @param  los argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        // Aquí puedes inicializar lo que necesites para la clase CadenaHoteles, si es necesario
        
        // Llamar al método main de InicioSesion.java
        IniciarSesion.main(args);
    }
}
/**
 * Clase para personalizar la representación de las habitaciones en la lista.
 */
// Clase para personalizar la representación de las habitaciones en la lista
class HabitacionListRenderer extends JLabel implements ListCellRenderer<Habitacion> {
    public Component getListCellRendererComponent(JList<? extends Habitacion> list, Habitacion habitacion, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        setText("Habitación " + habitacion.getNumero() + " - Tipo: " + habitacion.getTipo() +
                ", Estado: " + habitacion.getEstado());
        setOpaque(true);
        setBackground(isSelected ? list.getSelectionBackground() : list.getBackground());
        setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
        setFont(list.getFont());
        return this;
    }
}
