/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
/**
 * Representa un cliente en el sistema del hotel.
 */
public class Cliente {
    private int idCliente;
    private String nombre;
    private String apellido;
    private String email;
    /**
     * Constructor para inicializar un objeto Cliente.
     *
     * @param idCliente El ID del cliente.
     * @param nombre    El nombre del cliente.
     * @param apellido  El apellido del cliente.
     * @param email     El correo electrónico del cliente.
     */
    public Cliente(int idCliente, String nombre, String apellido, String email) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
    }

}
