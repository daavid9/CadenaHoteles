/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import java.sql.*;

/**
 * Clase utilitaria para manejar la conexión a la base de datos.
 */
public class BaseDeDatos {
    // Configuración de la conexión a la base de datos (cambiar según tu configuración)
    private static final String URL = "jdbc:mysql://localhost:3306/cadenahoteles";
    private static final String USUARIO = "root";
    private static final String CONTRASEÑA = "";
    /**
     * Obtiene una conexión activa a la base de datos.
     *
     */
    // Método para establecer la conexión con la base de datos
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);
    }
}
