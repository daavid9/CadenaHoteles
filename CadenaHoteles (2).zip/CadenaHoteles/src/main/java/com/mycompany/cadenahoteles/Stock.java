/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
/**
 * Clase que gestiona el stock de productos de un hotel.
 */
public class Stock {
    private JPanel panelStock;
    private JComboBox<String> hotelComboBox;
    private JTable stockTable;
    private DefaultTableModel tableModel;
   /**
     * Constructor de la clase Stock.
     */
    public Stock() {
        panelStock = new JPanel(new BorderLayout());

        cargarHotelesEnComboBox();

        // Inicializar la tabla con un modelo vacío
        String[] columnNames = {"ID Producto", "Nombre", "Precio", "Stock Actual", "Stock Mínimo", "Tipo Producto"};
        tableModel = new DefaultTableModel(columnNames, 0);
        stockTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(stockTable);
        panelStock.add(scrollPane, BorderLayout.CENTER);

        // Botones para editar y añadir productos
        JPanel buttonPanel = new JPanel();
        JButton editarButton = new JButton("Editar");
        JButton nuevoButton = new JButton("Nuevo");
        buttonPanel.add(editarButton);
        buttonPanel.add(nuevoButton);
        panelStock.add(buttonPanel, BorderLayout.SOUTH);

        // Action Listener para el botón de editar
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = stockTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Obtener datos de la fila seleccionada
                    int idProducto = (int) tableModel.getValueAt(selectedRow, 0);
                    String nombre = (String) tableModel.getValueAt(selectedRow, 1);
                    double precio = (double) tableModel.getValueAt(selectedRow, 2);
                    int stockActual = (int) tableModel.getValueAt(selectedRow, 3);
                    int stockMinimo = (int) tableModel.getValueAt(selectedRow, 4);
                    String tipoProducto = (String) tableModel.getValueAt(selectedRow, 5);

                    // Mostrar un JOptionPane para editar los datos
                    JTextField nombreField = new JTextField(nombre);
                    JTextField precioField = new JTextField(String.valueOf(precio));
                    JTextField stockActualField = new JTextField(String.valueOf(stockActual));
                    JTextField stockMinimoField = new JTextField(String.valueOf(stockMinimo));
                    JTextField tipoProductoField = new JTextField(tipoProducto);

                    JPanel editPanel = new JPanel(new GridLayout(5, 2));
                    editPanel.add(new JLabel("Nombre:"));
                    editPanel.add(nombreField);
                    editPanel.add(new JLabel("Precio:"));
                    editPanel.add(precioField);
                    editPanel.add(new JLabel("Stock Actual:"));
                    editPanel.add(stockActualField);
                    editPanel.add(new JLabel("Stock Mínimo:"));
                    editPanel.add(stockMinimoField);
                    editPanel.add(new JLabel("Tipo Producto:"));
                    editPanel.add(tipoProductoField);

                    int result = JOptionPane.showConfirmDialog(null, editPanel, "Editar Producto",
                            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        // Actualizar los datos en la tabla y en la base de datos
                        tableModel.setValueAt(nombreField.getText(), selectedRow, 1);
                        tableModel.setValueAt(Double.parseDouble(precioField.getText()), selectedRow, 2);
                        tableModel.setValueAt(Integer.parseInt(stockActualField.getText()), selectedRow, 3);
                        tableModel.setValueAt(Integer.parseInt(stockMinimoField.getText()), selectedRow, 4);
                        tableModel.setValueAt(tipoProductoField.getText(), selectedRow, 5);

                        actualizarProductoEnBD(idProducto, nombreField.getText(), Double.parseDouble(precioField.getText()),
                                Integer.parseInt(stockActualField.getText()), Integer.parseInt(stockMinimoField.getText()),
                                tipoProductoField.getText());
                    }
                } else {
                    JOptionPane.showMessageDialog(panelStock, "Selecciona un producto para editar.", "Editar Producto", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // Action Listener para el botón de nuevo
        nuevoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar un JOptionPane para ingresar un nuevo producto
                JTextField idField = new JTextField();
                JTextField nombreField = new JTextField();
                JTextField precioField = new JTextField();
                JTextField stockActualField = new JTextField();
                JTextField stockMinimoField = new JTextField();
                JTextField tipoProductoField = new JTextField();

                JPanel newPanel = new JPanel(new GridLayout(6, 2));
                newPanel.add(new JLabel("ID Producto:"));
                newPanel.add(idField);
                newPanel.add(new JLabel("Nombre:"));
                newPanel.add(nombreField);
                newPanel.add(new JLabel("Precio:"));
                newPanel.add(precioField);
                newPanel.add(new JLabel("Stock Actual:"));
                newPanel.add(stockActualField);
                newPanel.add(new JLabel("Stock Mínimo:"));
                newPanel.add(stockMinimoField);
                newPanel.add(new JLabel("Tipo Producto:"));
                newPanel.add(tipoProductoField);

                int result = JOptionPane.showConfirmDialog(null, newPanel, "Nuevo Producto",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    // Agregar el nuevo producto a la tabla y a la base de datos
                    Vector<Object> row = new Vector<>();
                    row.add(Integer.parseInt(idField.getText()));
                    row.add(nombreField.getText());
                    row.add(Double.parseDouble(precioField.getText()));
                    row.add(Integer.parseInt(stockActualField.getText()));
                    row.add(Integer.parseInt(stockMinimoField.getText()));
                    row.add(tipoProductoField.getText());
                    tableModel.addRow(row);

                    insertarProductoEnBD(Integer.parseInt(idField.getText()), nombreField.getText(), Double.parseDouble(precioField.getText()),
                            Integer.parseInt(stockActualField.getText()), Integer.parseInt(stockMinimoField.getText()),
                            tipoProductoField.getText());
                }
            }
        });

        // Crear un nuevo diálogo para mostrar el panel de stock
        JDialog dialog = new JDialog();
        dialog.setContentPane(panelStock);
        dialog.setTitle("Stock");
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);

        // Cargar productos al iniciar el diálogo
        cargarProductosDesdeBaseDeDatos();
    }
 /**
     * Método privado para cargar los nombres de los hoteles en un JComboBox.
     */
    private void cargarHotelesEnComboBox() {
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "SELECT nombre FROM hoteles";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (rs.next()) {
                model.addElement(rs.getString("nombre"));
            }
            hotelComboBox = new JComboBox<>(model);

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        panelStock.add(hotelComboBox, BorderLayout.NORTH);

        hotelComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarProductosDesdeBaseDeDatos();
            }
        });
    }
    /**
     * Método privado para cargar los productos desde la base de datos según el hotel seleccionado.
     */
    private void cargarProductosDesdeBaseDeDatos() {
        // Obtener el nombre del hotel seleccionado
        String hotelSeleccionado = (String) hotelComboBox.getSelectedItem();

        // Limpiar el modelo actual de la tabla
        tableModel.setRowCount(0);

        // Obtener los datos de los productos del hotel seleccionado desde la base de datos
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "SELECT * FROM productos WHERE idHotel IN (SELECT idHotel FROM hoteles WHERE nombre = ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, hotelSeleccionado);
            ResultSet rs = pstmt.executeQuery();

            // Agregar los datos a la tabla
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("idProducto"));
                row.add(rs.getString("Nombre"));
                row.add(rs.getDouble("Precio"));
                row.add(rs.getInt("Stock_Actual"));
                row.add(rs.getInt("Stock_Minimo"));
                row.add(rs.getString("Tipo_Producto"));
                tableModel.addRow(row);
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 /**
     * Método privado para actualizar los datos de un producto en la base de datos.
     * @param idProducto El ID del producto a actualizar.
     * @param precio El nuevo precio del producto.
     * @param stockActual El nuevo stock actual del producto.
     * @param stockMinimo El nuevo stock mínimo del producto.
     * @param tipoProducto El nuevo tipo de producto.
     */
    private void actualizarProductoEnBD(int idProducto, String nombre, double precio, int stockActual, int stockMinimo, String tipoProducto) {
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "UPDATE productos SET Nombre = ?, Precio = ?, Stock_Actual = ?, Stock_Minimo = ?, Tipo_Producto = ? WHERE idProducto = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            pstmt.setDouble(2, precio);
            pstmt.setInt(3, stockActual);
            pstmt.setInt(4, stockMinimo);
            pstmt.setString(5, tipoProducto);
            pstmt.setInt(6, idProducto);
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
  /**
     * Método privado para insertar un nuevo producto en la base de datos.
     * @param idProducto El ID del nuevo producto.
     * @param nombre El nombre del nuevo producto.
     * @param precio El precio del nuevo producto.
     * @param stockActual El stock actual del nuevo producto.
     * @param stockMinimo El stock mínimo del nuevo producto.
     * @param tipoProducto El tipo de producto del nuevo producto.
     */
    private void insertarProductoEnBD(int idProducto, String nombre, double precio, int stockActual, int stockMinimo, String tipoProducto) {
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "INSERT INTO productos (idProducto, Nombre, Precio, Stock_Actual, Stock_Minimo, Tipo_Producto) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

    pstmt.setInt(1, idProducto);
    pstmt.setString(2, nombre);
    pstmt.setDouble(3, precio);
    pstmt.setInt(4, stockActual);
    pstmt.setInt(5, stockMinimo);
    pstmt.setString(6, tipoProducto);
    pstmt.executeUpdate();

    pstmt.close();
    conn.close();
} catch (SQLException e) {
    e.printStackTrace();
}
}

void mostrarPanelStock() {
    cargarProductosDesdeBaseDeDatos(); // Actualizar la tabla al mostrar el panel
}

    

}

