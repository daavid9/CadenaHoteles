/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */

/**
 * Representa una habitación en un hotel.
 */
public class Habitacion {
    private int idHabitacion;
    private int numero;
    private String tipo;
    private String estado;
    private int idHotel;
    /**
     * Constructor para inicializar un objeto Habitacion.
     *
     * @param idHabitacion El ID de la habitación.
     * @param numero      El número de la habitación.
     * @param tipo        El tipo de habitación (por ejemplo, individual, doble, suite).
     * @param estado      El estado actual de la habitación (ocupada, libre, mantenimiento, etc.).
     * @param idHotel     El ID del hotel al que pertenece la habitación.
     */
    public Habitacion(int idHabitacion, int numero, String tipo, String estado, int idHotel) {
        this.idHabitacion = idHabitacion;
        this.numero = numero;
        this.tipo = tipo;
        this.estado = estado;
        this.idHotel = idHotel;
    }
    /**
     * Obtiene el ID de la habitación.
     *
     * @return El ID de la habitación.
     */
    public int getIdHabitacion() {
        return idHabitacion;
    }
    /**
     * Obtiene el número de la habitación.
     *
     * @return El número de la habitación.
     */
    public int getNumero() {
        return numero;
    }
    /**
     * Obtiene el tipo de la habitación.
     *
     * @return El tipo de la habitación.
     */
    public String getTipo() {
        return tipo;
    }
    /**
     * Obtiene el estado actual de la habitación.
     *
     * @return El estado actual de la habitación.
     */
    public String getEstado() {
        return estado;
    }
    /**
     * Obtiene el ID del hotel al que pertenece la habitación.
     *
     * @return El ID del hotel.
     */
    public int getIdHotel() {
        return idHotel;
    }
    /**
     * Devuelve una representación en cadena de la habitación.
     *
     * @return Cadena que describe la habitación con su número, tipo y estado.
     */
    @Override
    public String toString() {
        return "Habitación " + numero + " - Tipo: " + tipo + ", Estado: " + estado;
    }
}
