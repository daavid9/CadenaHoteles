/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

/**
 * Clase que gestiona la interfaz de usuario para visualizar y cargar horarios, días festivos y vacaciones.
 */
public class Horarios {
    private JPanel horariosPanel;
    private JTable diasFestivosTable;
    private JTable configuracionHorariosTable;
    private JTable vacacionesTable;

    /**
     * Constructor de la clase Horarios.
     */
    public Horarios() {
        horariosPanel = new JPanel();
        horariosPanel.setLayout(new BoxLayout(horariosPanel, BoxLayout.Y_AXIS));
        horariosPanel.setBackground(new Color(245, 245, 245));
        horariosPanel.setPreferredSize(new Dimension(500, 500));

        // Títulos de las secciones
        JPanel diasFestivosPanel = createTablePanelWithTitle("Días Festivos");
        JPanel configuracionHorariosPanel = createTablePanelWithTitle("Configuración de Horarios");
        JPanel vacacionesPanel = createTablePanelWithTitle("Vacaciones");

        // Crear y configurar las tablas
        diasFestivosTable = createStyledTable();
        configuracionHorariosTable = createStyledTable();
        vacacionesTable = createStyledTable();

        // Agregar las tablas a los paneles correspondientes
        diasFestivosPanel.add(new JScrollPane(diasFestivosTable));
        configuracionHorariosPanel.add(new JScrollPane(configuracionHorariosTable));
        vacacionesPanel.add(new JScrollPane(vacacionesTable));

        // Agregar los paneles con títulos al panel principal
        horariosPanel.add(diasFestivosPanel);
        horariosPanel.add(configuracionHorariosPanel);
        horariosPanel.add(vacacionesPanel);

        // Cargar datos en las tablas
        loadDiasFestivosData();
        loadVacacionesData();
    }

    /**
     * Método privado que crea un panel con un título para contener una tabla.
     * @param title El título del panel.
     * @return El JPanel creado.
     */
    private JPanel createTablePanelWithTitle(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245));

        JLabel titleLabel = createSectionLabel(title);
        panel.add(titleLabel, BorderLayout.NORTH);

        return panel;
    }
 /**
     * Método privado que crea una etiqueta para los títulos de las secciones.
     */
    private JLabel createSectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(new Color(0, 85, 128));
        label.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        return label;
    }
  /**
     * Método privado que crea una tabla con estilo personalizado.
     */
    private JTable createStyledTable() {
        JTable table = new JTable();
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(173, 216, 230));
        table.getTableHeader().setForeground(new Color(0, 85, 128));
        table.setRowHeight(25);
        table.setGridColor(new Color(200, 200, 200));
        return table;
    }
/**
     * Método privado que carga los datos de días festivos desde la base de datos a la tabla correspondiente.
     */
    private void loadDiasFestivosData() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID Festivo", "Fecha Festivo", "Descripción"}, 0);
        try {
            Connection conn = BaseDeDatos.getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM dias_festivos");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("idFestivo"), rs.getDate("fecha_festivo"), rs.getString("descripcion")});
            }
            diasFestivosTable.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  /**
     * Método privado que carga los datos de vacaciones desde la base de datos a la tabla correspondiente.
     */
    private void loadVacacionesData() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID Vacación", "ID Empleado", "Fecha Inicio", "Fecha Fin", "Motivo"}, 0);
        try {
            Connection conn = BaseDeDatos.getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM vacaciones");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("idVacacion"), rs.getInt("idEmpleado"), rs.getDate("fecha_inicio"), rs.getDate("fecha_fin"), rs.getString("motivo")});
            }
            vacacionesTable.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  /**
     * Método público que muestra el panel de horarios en un JFrame.
     */
    public void mostrarPanelHorarios() {
        JFrame horariosFrame = new JFrame("Horarios y Vacaciones");
        horariosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        horariosFrame.setContentPane(this.getPanel());
        horariosFrame.setSize(800, 700); // Establecer tamaño fijo
        horariosFrame.setLocationRelativeTo(null);
        horariosFrame.setVisible(true);
    }
  /**
     * Método público que devuelve el panel principal de horarios.
     * @return El JPanel que contiene la interfaz de horarios.
     */
    public JPanel getPanel() {
        return horariosPanel;
    }
 /**
     * Método público que carga el horario de un empleado específico en la tabla de configuración de horarios.
     * @param idEmpleado El ID del empleado cuyo horario se desea cargar.
     */
    public void cargarHorarioEmpleado(int idEmpleado) {
        DefaultTableModel modelo = new DefaultTableModel(new String[]{"ID", "Hora Entrada Esperada", "Hora Salida Esperada", "Días Laborables"}, 0);
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "SELECT idHorario, hora_entrada_esperada, hora_salida_esperada, dias_laborables FROM configuracion_horarios WHERE idEmpleado = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idEmpleado);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int idHorario = rs.getInt("idHorario");
                Time horaEntrada = rs.getTime("hora_entrada_esperada");
                Time horaSalida = rs.getTime("hora_salida_esperada");
                String diasLaborables = rs.getString("dias_laborables");

                modelo.addRow(new Object[]{idHorario, horaEntrada, horaSalida, diasLaborables});
            }

            configuracionHorariosTable.setModel(modelo);

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
