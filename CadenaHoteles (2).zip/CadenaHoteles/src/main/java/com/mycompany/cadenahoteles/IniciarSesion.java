/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.*;
/**
 * Clase que representa la ventana de inicio de sesión de usuarios.
 * Extiende JFrame para manejar la interfaz gráfica.
 */
public class IniciarSesion extends JFrame {
    private JPasswordField usuarioField; // Cambiado a JPasswordField
    private JPasswordField contrasenaField;
    private JLabel background;
    private Fichaje fichaje;
/**
     * Constructor de la clase IniciarSesion.
     * Configura la interfaz gráfica y los componentes necesarios.
     */
    public IniciarSesion() {
        super("Inicio de Sesión");

        // Configuración del estilo
        UIManager.put("OptionPane.background", new Color(207,189,203));
        UIManager.put("Panel.background", new Color(207,189,203));

        // Configurar el frame
        setSize(700, 500); // Ajustar el tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Crear un JLabel para la imagen de fondo
        background = new JLabel(new ImageIcon("src/imagen/background_image.jpg")) {
            @Override
            public Dimension getPreferredSize() {
                return getContentPane().getSize(); // Tamaño de la ventana
            }
        };
        add(background);

        // Ajustar el tamaño del JLabel para que ocupe toda la ventana
        background.setLayout(new BorderLayout());
        setContentPane(background);
        background.setLayout(new GridBagLayout()); // Usar GridBagLayout para centrar los componentes

        // Panel principal
        JPanel panelPrincipal = new JPanel(new GridBagLayout());

        // Ajustes de los campos
        usuarioField = new JPasswordField(); // Cambiado a JPasswordField
        usuarioField.setFont(new Font("Arial", Font.PLAIN, 15));
        usuarioField.setForeground(Color.WHITE); // Cambiado a negro
        usuarioField.setBackground(new Color(0, 85, 128));
        usuarioField.setPreferredSize(new Dimension(350, 40));
        usuarioField.setEchoChar((char) 0);//Sire para que se vean las palabras que pones
        usuarioField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (String.valueOf(usuarioField.getPassword()).equals("Usuario")) {
                    usuarioField.setText("");
                    usuarioField.setEchoChar((char) 0);
                    usuarioField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (String.valueOf(usuarioField.getPassword()).isEmpty()) {
                    usuarioField.setEchoChar((char) 0);
                    usuarioField.setForeground(Color.BLACK); // Cambiado a negro
                }
            }
        });

        contrasenaField = new JPasswordField(); // Quitamos el texto predeterminado "Contraseña"
        contrasenaField.setFont(new Font("Arial", Font.PLAIN, 15));
        contrasenaField.setForeground(Color.WHITE); // Cambiado a negro
        contrasenaField.setBackground(new Color(0, 85, 128));
        contrasenaField.setPreferredSize(new Dimension(350, 40));
        contrasenaField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (String.valueOf(contrasenaField.getPassword()).equals("Contraseña")) {
                    contrasenaField.setText("");
                    contrasenaField.setForeground(Color.BLACK); // Cambiado a negro
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (String.valueOf(contrasenaField.getPassword()).isEmpty()) {
                    contrasenaField.setForeground(Color.BLACK); // Cambiado a negro
                }
            }
        });

        JButton iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.setFont(new Font("Arial", Font.BOLD, 15));
        iniciarSesionButton.setBackground(new Color(173, 216, 230));
        iniciarSesionButton.setForeground(new Color(0, 85, 128));
        iniciarSesionButton.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50)); // Añadir espacio alrededor del texto

    

        // Acción del botón de iniciar sesión
        iniciarSesionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });

        // Agregar componentes al panel principal
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panelPrincipal.add(createPanelWithImage("src/imagen/usuario_icono.jpg", usuarioField), gbc);

        gbc.gridy++;
        panelPrincipal.add(createPanelWithImage("src/imagen/contrasena_icono.jpg", contrasenaField), gbc);

        gbc.gridy++;
        panelPrincipal.add(iniciarSesionButton, gbc);

        // Agregar el panel principal al JLabel de fondo
        GridBagConstraints gbcPrincipal = new GridBagConstraints();
        gbcPrincipal.gridx = 0;
        gbcPrincipal.gridy = 0;
        gbcPrincipal.weightx = 1;
        gbcPrincipal.weighty = 1;
        gbcPrincipal.anchor = GridBagConstraints.CENTER;
        background.add(panelPrincipal, gbcPrincipal);
    }
    // Método para iniciar sesión
    
/**
     * Método para iniciar sesión utilizando los datos ingresados en los campos de usuario y contraseña.
     */
private void iniciarSesion() {
    String usuario = String.valueOf(usuarioField.getPassword());
    String contrasena = String.valueOf(contrasenaField.getPassword());

    boolean credencialesValidas = verificarCredenciales(usuario, contrasena);

    if (credencialesValidas) {
        int idEmpleado = obtenerIdEmpleado(usuario);

        if (idEmpleado != -1) {
            fichaje = new Fichaje(idEmpleado);
            fichaje.verificarHoraLlegada();

            // Pasar el ID del empleado a la ventana principal
            abrirVentanaPrincipal(idEmpleado);
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo obtener el ID del empleado", "Error", JOptionPane.ERROR_MESSAGE);
        }

        setVisible(false);
        dispose();
    } else {
        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
 /**
     * Método para abrir la ventana principal de la aplicación con el ID del empleado.
     * @param  El ID del empleado que ha iniciado sesión.
     */
private void abrirVentanaPrincipal(int idEmpleado) {
    SwingUtilities.invokeLater(new Runnable() {
        public void run() {
            CadenaHoteles ventana = new CadenaHoteles(idEmpleado);
            ventana.setVisible(true);
        }
    });
}
/**
     * Método para verificar las credenciales de inicio de sesión en la base de datos.
     * @param usuario El nombre de usuario ingresado.
     * @param contrasena La contraseña ingresada.
     * @return true si las credenciales son válidas, false en caso contrario.
     */
//Verificación de las credenciales con la base de datos
    private boolean verificarCredenciales(String usuario, String contrasena) {
        boolean credencialesValidas = false;

        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "SELECT * FROM empleados WHERE nombre_usuario = ? AND contrasena = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, usuario);
            pstmt.setString(2, contrasena);
            ResultSet rs = pstmt.executeQuery();

            credencialesValidas = rs.next();

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return credencialesValidas;
    }
    
   /**
     * Método para obtener el ID del empleado a partir del nombre de usuario.
     * @param nombreUsuario El nombre de usuario del empleado.
    */
    
    private int obtenerIdEmpleado(String nombreUsuario) {
    int idEmpleado = -1; // Valor predeterminado en caso de error o no encontrar el empleado

    try {
        Connection conn = BaseDeDatos.getConnection();
        String sql = "SELECT idEmpleado FROM empleados WHERE nombre_usuario = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, nombreUsuario);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            idEmpleado = rs.getInt("idEmpleado");
        }

        rs.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return idEmpleado;
}

/**
     * Método para crear un panel con una imagen a la izquierda del componente.
     * @return El JPanel que contiene la imagen y el componente.
     */
    // Método para crear un panel con una imagen a la izquierda del componente
    private JPanel createPanelWithImage(String imagePath, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel imageLabel = new JLabel(new ImageIcon(imagePath));
        panel.add(imageLabel, BorderLayout.WEST);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }
    
    
  /**
     * Método principal (main) de la aplicación.
     * @param args Los argumentos de la línea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                IniciarSesion ventanaInicioSesion = new IniciarSesion();
                ventanaInicioSesion.setVisible(true);
            }
        });
    }
}
