/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Calendar;
/**
 * Clase que maneja el registro de fichaje de un empleado, verificando la hora de llegada
 * y permitiendo el registro de retrasos.
 */
public class Fichaje {
    private int idEmpleado;
    /**
     * Constructor de la clase Fichaje.
     * @param idEmpleado El ID del empleado para el cual se registra el fichaje.
     */
    public Fichaje(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
    /**
     * Método privado que verifica si el empleado llegó tarde comparando la hora de entrada esperada
     * con la hora actual.
     * @param horaEntradaEsperada La hora de entrada esperada para el empleado.
     * @param horaActual La hora actual en la que el empleado llega.
     * @return true si el empleado llegó tarde, false si llegó a tiempo.
     */
    private boolean llegoTarde(Time horaEntradaEsperada, Time horaActual) {
        Calendar calEsperada = Calendar.getInstance();
        calEsperada.setTime(horaEntradaEsperada);
        Calendar calActual = Calendar.getInstance();
        calActual.setTime(horaActual);

        int horaEsperada = calEsperada.get(Calendar.HOUR_OF_DAY);
        int minutoEsperado = calEsperada.get(Calendar.MINUTE);

        int horaActual1 = calActual.get(Calendar.HOUR_OF_DAY);
        int minutoActual = calActual.get(Calendar.MINUTE);

        if (horaActual1 > horaEsperada) {
            return true;
        } else if (horaActual1 == horaEsperada && minutoActual > minutoEsperado) {
            return true;
        } else {
            return false;
        }
    }
 /**
     * Método público que verifica la hora de llegada del empleado según la configuración de horarios.
     * Muestra un mensaje según si llegó tarde y permite registrar el motivo del retraso en caso necesario.
     */
   void verificarHoraLlegada() {
    try {
        Connection conn = BaseDeDatos.getConnection();
        String sql = "SELECT hora_entrada_esperada FROM configuracion_horarios WHERE idEmpleado = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, idEmpleado);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            Time horaEntradaEsperada = rs.getTime("hora_entrada_esperada");
            Time horaActual = new Time(System.currentTimeMillis());

            // Agregar logs para depuración
            System.out.println("Hora entrada esperada: " + horaEntradaEsperada);
            System.out.println("Hora actual: " + horaActual);

            if (llegoTarde(horaEntradaEsperada, horaActual)) {
                long diferencia = horaActual.getTime() - horaEntradaEsperada.getTime();
                int minutosDeRetraso = (int) (diferencia / (1000 * 60));
                System.out.println("Minutos de retraso: " + minutosDeRetraso);

                if (minutosDeRetraso > 5) {
                    mostrarPanelRetraso(horaActual, minutosDeRetraso);
                } else {
                    mostrarMensaje("Registro exitoso. No hay retraso.");
                }
            } else {
                mostrarMensaje("Llegada a tiempo.");
            }
        } else {
            mostrarMensaje("No se encontró la configuración de horario para el empleado.");
        }

        rs.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        mostrarMensaje("Error al verificar la hora de llegada.");
    }
}

 /**
     * Método que muestra un panel para registrar el motivo de un retraso en la llegada.
     * @param horaLlegada La hora en la que el empleado llegó tarde.
     * @param minutosDeRetraso Los minutos de retraso en la llegada.
     */
    public void mostrarPanelRetraso(Time horaLlegada, int minutosDeRetraso) {
        JDialog dialog = new JDialog((Frame) null, "Motivo de Retraso", true);
        dialog.setSize(400, 200);
        dialog.setLocationRelativeTo(null);
        dialog.setLayout(new BorderLayout());

        JLabel motivoLabel = new JLabel("Motivo del retraso:");
        JTextField motivoField = new JTextField();
        JButton guardarButton = new JButton("Guardar");

        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.add(motivoLabel);
        panel.add(motivoField);

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(guardarButton, BorderLayout.SOUTH);

        guardarButton.addActionListener(e -> {
            String motivo = motivoField.getText();
            guardarRetraso(horaLlegada, minutosDeRetraso, motivo);
            dialog.dispose();
        });

        dialog.setVisible(true);
    }
/**
     * Método privado que guarda el motivo del retraso en la base de datos.
     * @param motivo El motivo del retraso.
     */
    public void guardarRetraso(Time horaLlegada, int minutosDeRetraso, String motivo) {
        try {
            Connection conn = BaseDeDatos.getConnection();
            String sql = "INSERT INTO historial_retrasos (idEmpleado, fecha, hora_llegada_tardia, tiempo_de_retraso, motivo) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idEmpleado);
            pstmt.setDate(2, new java.sql.Date(System.currentTimeMillis()));
            pstmt.setTime(3, horaLlegada);
            pstmt.setInt(4, minutosDeRetraso);
            pstmt.setString(5, motivo);
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            mostrarMensaje("Motivo de retraso guardado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error al guardar el motivo de retraso.");
        }
    }
 /**
     * Método privado para mostrar un mensaje usando JOptionPane.
     * @param mensaje El mensaje a mostrar.
     */
    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje);
    }

  
}






