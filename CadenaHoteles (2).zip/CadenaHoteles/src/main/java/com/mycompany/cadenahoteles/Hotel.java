/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

import java.util.List;
import javax.swing.ImageIcon;

/**
 *
 * @author david.b
 */

/**
 * Clase que representa un hotel con su información básica.
 */
public class Hotel {
    private int idHotel;
    private String nombre;
    private String direccion;

    /**
     * Constructor para inicializar un objeto Hotel con su identificador único, nombre y dirección.
     *
     * @param idHotel   El identificador único del hotel.
     * @param nombre    El nombre del hotel.
     * @param direccion La dirección física del hotel.
     */
    public Hotel(int idHotel, String nombre, String direccion) {
        this.idHotel = idHotel;
        this.nombre = nombre;
        this.direccion = direccion;
    }
    /**
     * Método para obtener el identificador único del hotel.
     *
     * @return El identificador único del hotel.
     */
    public int getIdHotel() {
        return idHotel;
    }
    /**
     * Método para obtener el nombre del hotel.
     *
     * @return El nombre del hotel.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método para obtener la dirección física del hotel.
     *
     * @return La dirección física del hotel.
     */
    public String getDireccion() {
        return direccion;
    }
    /**
     * Sobrescribe el método toString() para proporcionar una representación en cadena del objeto Hotel.
     *
     * @return El nombre del hotel como representación en cadena.
     */
    @Override
    public String toString() {
        return nombre; // Cambiar aquí según cómo quieras que se represente el hotel como cadena
    }
}
