/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * Clase que gestiona la interfaz de usuario para manejar solicitudes de devolución.
 */
public class Devolucion {
    private JPanel devolucionPanel;
    private JTable devolucionesTable;
   /**
     * Constructor de la clase Devolucion.
     */
    public Devolucion() {
        devolucionPanel = new JPanel();
        devolucionPanel.setLayout(new BoxLayout(devolucionPanel, BoxLayout.Y_AXIS));
        devolucionPanel.setBackground(new Color(245, 245, 245));
        devolucionPanel.setPreferredSize(new Dimension(500, 500));

        // Título de la sección
        JLabel devolucionesLabel = createSectionLabel("Solicitudes de Devolución");

        // Crear y configurar la tabla
        devolucionesTable = createStyledTable();

        // Cargar datos en la tabla
        loadDevolucionesData();

        // Crear y configurar el botón "Editar"
        JButton editarButton = new JButton("Editar");
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarDevolucion();
            }
        });

        // Agregar componentes al panel
        devolucionPanel.add(devolucionesLabel);
        devolucionPanel.add(createTablePanel(devolucionesTable));
        devolucionPanel.add(editarButton);
    }
    /**
     * Método privado que crea una etiqueta para los títulos de sección.
     */
    private JLabel createSectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(new Color(0, 85, 128));
        label.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        return label;
    }
    /**
     * Método privado que crea una tabla con estilo personalizado.
     */
    private JTable createStyledTable() {
        JTable table = new JTable();
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(173, 216, 230));
        table.getTableHeader().setForeground(new Color(0, 85, 128));
        table.setRowHeight(25);
        table.setGridColor(new Color(200, 200, 200));
        return table;
    }
   /**
     * Método privado que crea un panel con JScrollPane para contener una tabla.
     */
    private JScrollPane createTablePanel(JTable table) {
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        return scrollPane;
    }
    /**
     * Método privado que carga los datos de las solicitudes de devolución desde la base de datos a la tabla correspondiente.
     */
    void loadDevolucionesData() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID Solicitud", "ID Cliente", "Fecha Solicitud", "Motivo", "Estado", "ID Empleado"}, 0);
        try {
            Connection conn = BaseDeDatos.getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM solicitudes_devolucion");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("idSolicitud"), rs.getInt("idCliente"), rs.getDate("fecha_solicitud"), rs.getString("motivo"), rs.getString("estado"), rs.getInt("idEmpleado")});
            }
            devolucionesTable.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Método privado que maneja la acción de editar una solicitud de devolución seleccionada.
     */
    private void editarDevolucion() {
        int selectedRow = devolucionesTable.getSelectedRow();
        if (selectedRow != -1) {
            int idSolicitud = (int) devolucionesTable.getValueAt(selectedRow, 0);
            String estadoActual = (String) devolucionesTable.getValueAt(selectedRow, 4);

            // Crear el diálogo de edición
            JDialog editarDialog = new JDialog();
            editarDialog.setTitle("Editar Estado de Devolución");
            editarDialog.setSize(300, 200);
            editarDialog.setLayout(new BorderLayout());
            editarDialog.setLocationRelativeTo(null);

            // Crear componentes del diálogo
            JPanel panel = new JPanel(new GridLayout(2, 2));
            panel.add(new JLabel("ID Solicitud:"));
            panel.add(new JLabel(String.valueOf(idSolicitud)));
            panel.add(new JLabel("Estado:"));
            JComboBox<String> estadoComboBox = new JComboBox<>(new String[]{"pendiente", "aprobada", "rechazada"});
            estadoComboBox.setSelectedItem(estadoActual);
            panel.add(estadoComboBox);

            JButton guardarButton = new JButton("Guardar");
            guardarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String nuevoEstado = (String) estadoComboBox.getSelectedItem();
                    actualizarEstadoDevolucion(idSolicitud, nuevoEstado);
                    editarDialog.dispose();
                    loadDevolucionesData();
                }
            });

            // Agregar componentes al diálogo
            editarDialog.add(panel, BorderLayout.CENTER);
            editarDialog.add(guardarButton, BorderLayout.SOUTH);
            editarDialog.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una solicitud para editar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Método privado que actualiza el estado de una solicitud de devolución en la base de datos.
     * @param idSolicitud El ID de la solicitud a actualizar.
     * @param nuevoEstado El nuevo estado a asignar a la solicitud.
     */
    private void actualizarEstadoDevolucion(int idSolicitud, String nuevoEstado) {
        try {
            Connection conn = BaseDeDatos.getConnection();
            PreparedStatement stmt = conn.prepareStatement("UPDATE solicitudes_devolucion SET estado = ? WHERE idSolicitud = ?");
            stmt.setString(1, nuevoEstado);
            stmt.setInt(2, idSolicitud);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método público que muestra el panel de devolución en un JFrame.
     */
    public void mostrarPanelDevolucion() {
        JFrame devolucionFrame = new JFrame("Solicitudes de Devolución");
        devolucionFrame.setContentPane(this.getPanel());
        devolucionFrame.setSize(500, 500); // Establecer tamaño fijo
        devolucionFrame.setLocationRelativeTo(null);
        devolucionFrame.setVisible(true);
    }
    /**
     * Método público que devuelve el panel principal de devolución.
     * @return El JPanel que contiene la interfaz de devolución.
     */
    public JPanel getPanel() {
        return devolucionPanel;
    }
}
