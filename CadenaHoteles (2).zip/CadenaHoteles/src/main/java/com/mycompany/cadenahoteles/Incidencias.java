/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadenahoteles;

/**
 *
 * @author david.b
 */
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

/**
 * Esta clase gestiona las incidencias registradas y permite su visualización y edición.
 */
public class Incidencias {
    private JPanel panelIncidencias;
    private JTable table;
/**
     * Constructor de la clase Incidencias.
     * Aquí se inicializa el botón para mostrar el panel de incidencias.
     */
    public Incidencias() {
        // Botón de incidencias
        JButton incidenciasButton = new JButton("Incidencias");
        incidenciasButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Mostrar el panel de incidencias
                mostrarPanelIncidencias();
            }
        });
        //add(incidenciasButton, BorderLayout.SOUTH);
    }

    
    
     /**
     * Método para mostrar el panel de incidencias.
     * Aquí se carga la tabla con los datos de las incidencias y se gestiona la interacción con el usuario.
     */
    void mostrarPanelIncidencias() {
        // Crear el panel de incidencias
        panelIncidencias = new JPanel(new BorderLayout());

        // Obtener las incidencias desde la base de datos
        Vector<Vector<Object>> data = obtenerIncidencias();

        // Definir las columnas de la tabla de incidencias
        Vector<String> columnNames = new Vector<>();
        columnNames.add("ID");
        columnNames.add("ID Cliente");
        columnNames.add("Fecha Creación");
        columnNames.add("Estado");
        columnNames.add("Texto");

        // Crear la tabla de incidencias
        table = new JTable(data, columnNames);

        // Agregar el escuchador de eventos a la tabla
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        // Obtener el ID de la incidencia seleccionada
                        int idIncidencia = (int) table.getValueAt(selectedRow, 0);
                        // Obtener los detalles de la incidencia desde la base de datos
                        // y abrir un panel nuevo para mostrar los detalles
                        mostrarDetallesIncidencia(idIncidencia);
                    }
                }
            }
        });

        // Agregar la tabla a un JScrollPane y luego al panel de incidencias
        JScrollPane scrollPane = new JScrollPane(table);
        panelIncidencias.add(scrollPane, BorderLayout.CENTER);

        // Agregar el botón "Editar" al panel de incidencias
        JButton editarButton = new JButton("Editar");
        editarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Obtener el ID de la incidencia seleccionada
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int idIncidencia = (int) table.getValueAt(selectedRow, 0);
                    // Llamar al método para editar la incidencia
                    editarIncidencia(idIncidencia);
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione una incidencia para editar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panelIncidencias.add(editarButton, BorderLayout.SOUTH);

        // Crear un nuevo diálogo para mostrar el panel de incidencias
        JDialog dialog = new JDialog();
        dialog.setContentPane(panelIncidencias);
        dialog.setTitle("Incidencias");
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }

    
    
    
    
  /**
     * Método privado para editar una incidencia existente.
     * @param  El ID de la incidencia a editar.
     */
private void editarIncidencia(int idIncidencia) {
    // Obtener los detalles de la incidencia desde la base de datos
    String textoIncidencia = "";
    String estadoIncidencia = "";
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadenahoteles", "root", "");
        String sql = "SELECT texto_incidencia, estado_incidencia FROM incidencias WHERE idIncidencia = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, idIncidencia);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            textoIncidencia = rs.getString("texto_incidencia");
            estadoIncidencia = rs.getString("estado_incidencia");
        }
        rs.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Crear el diálogo de edición de incidencias
    JDialog dialog = new JDialog();
    dialog.setTitle("Editar Incidencia");
    dialog.setSize(400, 200);
    dialog.setLocationRelativeTo(null);
    dialog.setLayout(new BorderLayout());

    // Panel para los campos de texto y estado
    JPanel inputPanel = new JPanel(new GridLayout(2, 2));
    inputPanel.add(new JLabel("Texto de la Incidencia:"));
    JTextField textoIncidenciaField = new JTextField(textoIncidencia);
    inputPanel.add(textoIncidenciaField);
    inputPanel.add(new JLabel("Estado de la Incidencia:"));
    String[] estados = {"abierto", "en proceso", "cerrado"};
    JComboBox<String> estadoIncidenciaComboBox = new JComboBox<>(estados);
    estadoIncidenciaComboBox.setSelectedItem(estadoIncidencia);
    inputPanel.add(estadoIncidenciaComboBox);
    dialog.add(inputPanel, BorderLayout.CENTER);

    // Botón de guardar cambios
    JButton guardarButton = new JButton("Guardar Cambios");
    guardarButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Obtener los nuevos valores de texto y estado
            String nuevoTextoIncidencia = textoIncidenciaField.getText();
            String nuevoEstadoIncidencia = (String) estadoIncidenciaComboBox.getSelectedItem();
            
            // Actualizar los datos en la base de datos
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadenahoteles", "root", "");
                String updateSql = "UPDATE incidencias SET texto_incidencia = ?, estado_incidencia = ? WHERE idIncidencia = ?";
                PreparedStatement pstmt = conn.prepareStatement(updateSql);
                pstmt.setString(1, nuevoTextoIncidencia);
                pstmt.setString(2, nuevoEstadoIncidencia);
                pstmt.setInt(3, idIncidencia);
                pstmt.executeUpdate();
                pstmt.close();
                conn.close();
                System.out.println("Incidencia actualizada en la base de datos.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Error al actualizar la incidencia en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Cerrar el diálogo después de guardar los cambios
            dialog.dispose();
        }
    });
    dialog.add(guardarButton, BorderLayout.SOUTH);

    // Mostrar el diálogo de edición
    dialog.setModal(true); // Hacer que el diálogo sea modal para bloquear la interacción con la ventana principal
    dialog.setVisible(true);
}




  /**
     * Clase interna que representa el panel de detalles de una incidencia.
     * Aquí se muestran y gestionan las respuestas asociadas a la incidencia.
     */
public class DetallesIncidenciaPanel extends JPanel {
    private int idIncidencia;
    private JTextArea textoRespuestaArea;
    private JComboBox<String> estadoRespuestaComboBox;

    public DetallesIncidenciaPanel(int idIncidencia) {
        this.idIncidencia = idIncidencia;

        // Configuración del panel de detalles de la incidencia
        setLayout(new BorderLayout());

        // Crear componentes para mostrar y modificar respuestas
        JPanel respuestasPanel = new JPanel(new BorderLayout());
        cargarRespuestas();

        // Crear un área de texto para ingresar nuevas respuestas
        JPanel nuevaRespuestaPanel = new JPanel(new BorderLayout());
        JLabel nuevaRespuestaLabel = new JLabel("Nueva respuesta:");
        textoRespuestaArea = new JTextArea(5, 20);
        JScrollPane scrollPane = new JScrollPane(textoRespuestaArea);
        nuevaRespuestaPanel.add(nuevaRespuestaLabel, BorderLayout.NORTH);
        nuevaRespuestaPanel.add(scrollPane, BorderLayout.CENTER);

        // Crear un ComboBox para seleccionar el estado de la respuesta
        JPanel estadoRespuestaPanel = new JPanel(new BorderLayout());
        JLabel estadoRespuestaLabel = new JLabel("Estado:");
        String[] estados = {"pendiente", "enviada", "leida"};
        estadoRespuestaComboBox = new JComboBox<>(estados);
        estadoRespuestaPanel.add(estadoRespuestaLabel, BorderLayout.WEST);
        estadoRespuestaPanel.add(estadoRespuestaComboBox, BorderLayout.CENTER);

        // Crear un botón para agregar una nueva respuesta
        JButton agregarRespuestaButton = new JButton("Agregar Respuesta");
        agregarRespuestaButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarRespuesta();
            }
        });

        // Agregar componentes al panel de nueva respuesta
        nuevaRespuestaPanel.add(estadoRespuestaPanel, BorderLayout.SOUTH);
        nuevaRespuestaPanel.add(agregarRespuestaButton, BorderLayout.SOUTH);

        // Agregar componentes al panel de respuestas
        respuestasPanel.add(nuevaRespuestaPanel, BorderLayout.NORTH);
        add(respuestasPanel, BorderLayout.CENTER);
    }   
    
     /**
         * Método privado para cargar y mostrar las respuestas asociadas a la incidencia.
         */
private void cargarRespuestas() {
        // Lógica para cargar y mostrar las respuestas asociadas a la incidencia
        JPanel respuestasPanel = new JPanel(new GridLayout(0, 1));

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadenahoteles", "root", "");
            String sql = "SELECT * FROM respuestas WHERE idIncidencia = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idIncidencia);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                JPanel respuestaPanel = new JPanel(new BorderLayout());
                respuestaPanel.setBorder(BorderFactory.createEtchedBorder());
                JLabel fechaLabel = new JLabel("Fecha: " + rs.getTimestamp("fecha_respuesta"));
                JTextArea textoArea = new JTextArea(rs.getString("texto_respuesta"));
                textoArea.setEditable(false);
                respuestaPanel.add(fechaLabel, BorderLayout.NORTH);
                respuestaPanel.add(textoArea, BorderLayout.CENTER);
                respuestasPanel.add(respuestaPanel);
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(respuestasPanel);
        add(scrollPane, BorderLayout.CENTER);
    }

    
    

   /**
         * Método privado para agregar una nueva respuesta a la incidencia en la base de datos.
         */
private void agregarRespuesta() {
        // Lógica para agregar una nueva respuesta a la base de datos
        String textoRespuesta = textoRespuestaArea.getText();
        String estadoRespuesta = (String) estadoRespuestaComboBox.getSelectedItem();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadenahoteles", "root", "");
            String sql = "INSERT INTO respuestas (idIncidencia, texto_respuesta, estado_respuesta) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idIncidencia);
            pstmt.setString(2, textoRespuesta);
            pstmt.setString(3, estadoRespuesta);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            // Recargar las respuestas después de agregar una nueva
            cargarRespuestas();
            textoRespuestaArea.setText(""); // Limpiar el área de texto después de agregar
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

    /**
     * Método privado para mostrar los detalles de una incidencia seleccionada.
     * @param idIncidencia El ID de la incidencia seleccionada.
     */
private void mostrarDetallesIncidencia(int idIncidencia) {
    // Crear una instancia del panel de detalles de la incidencia
    DetallesIncidenciaPanel detallesPanel = new DetallesIncidenciaPanel(idIncidencia);

    // Crear un nuevo diálogo para mostrar los detalles de la incidencia
    JDialog dialog = new JDialog();
    dialog.setTitle("Detalles de la incidencia");
    dialog.setModal(true);
    dialog.getContentPane().add(detallesPanel);
    dialog.setSize(400, 300);
    dialog.setVisible(true);
}
private Vector<Vector<Object>> obtenerIncidencias() {
        Vector<Vector<Object>> data = new Vector<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadenahoteles", "root", "");
            String sql = "SELECT * FROM incidencias";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                Vector<Object> row = new Vector<>();
                row.add(resultSet.getInt("idIncidencia"));
                row.add(resultSet.getInt("idCliente"));
                row.add(resultSet.getTimestamp("fecha_creacion"));
                row.add(resultSet.getString("estado_incidencia"));
                row.add(resultSet.getString("texto_incidencia"));
                data.add(row);
            }

            resultSet.close();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }


}
